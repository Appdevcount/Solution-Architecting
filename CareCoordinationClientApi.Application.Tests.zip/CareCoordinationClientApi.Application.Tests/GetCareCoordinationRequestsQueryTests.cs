using Xunit;
using CareCoordinationClientAPI.Queries;
using System;

namespace CareCoordinationClientApi.Application.Tests
{
    public class GetCareCoordinationRequestsQueryTests
    {
        [Fact]
        public void Constructor_SetsProperties()
        {
            var query = new GetCareCoordinationRequestsQuery("fn", "ln", new DateTime(2020,1,1), "pid", "ccid");
            Assert.Equal("fn", query.PatientFirstname);
            Assert.Equal("ln", query.PatientLastname);
            Assert.Equal(new DateTime(2020,1,1), query.PatientDOB);
            Assert.Equal("pid", query.PatientId);
            Assert.Equal("ccid", query.CCRequestId);
        }
    }
}
