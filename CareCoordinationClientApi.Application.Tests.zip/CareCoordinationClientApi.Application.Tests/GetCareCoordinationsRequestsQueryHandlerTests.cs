using Xunit;
using Moq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using CareCoordinationClientAPI.Queries.Handlers;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Queries;
using CareCoordinationClientAPI.Dto;
using System.Collections.Generic;
using CareCoordinationClientAPI.Domain.Models;

namespace CareCoordinationClientApi.Application.Tests
{
    public class GetCareCoordinationsRequestsQueryHandlerTests
    {
        private readonly Mock<IGetCareCoordinationRequest> _serviceMock = new();
        private readonly Mock<IMapper> _mapperMock = new();
        private readonly GetCareCoordinationsRequestsQueryHandler _handler;

        public GetCareCoordinationsRequestsQueryHandlerTests()
        {
            _handler = new GetCareCoordinationsRequestsQueryHandler(_serviceMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task Handle_ReturnsRequests()
        {
            var query = new GetCareCoordinationRequestsQuery("fn","ln",null,"pid","ccid");
            var dto = new CCRequestDto();
            var list = new List<CareCoordination> { new CareCoordination() };
            _mapperMock.Setup(m => m.Map<CCRequestDto>(query)).Returns(dto);
            _serviceMock.Setup(s => s.SearchRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(list);
            var result = await _handler.Handle(query, CancellationToken.None);
            Assert.Single(result);
        }

        [Fact]
        public async Task Handle_MapsAndReturnsRequests()
        {
            var getCareCoordinationRequestMock = new Mock<IGetCareCoordinationRequest>();
            var mapperMock = new Mock<IMapper>();
            var handler = new GetCareCoordinationsRequestsQueryHandler(getCareCoordinationRequestMock.Object, mapperMock.Object);
            var query = new CareCoordinationClientAPI.Queries.GetCareCoordinationRequestsQuery("fn", "ln", DateTime.Now, "pid", "ccid");
            var dto = new CareCoordinationClientAPI.Dto.CCRequestDto();
            var expected = new List<CareCoordinationClientAPI.Domain.Models.CareCoordination> { new CareCoordinationClientAPI.Domain.Models.CareCoordination() };
            mapperMock.Setup(m => m.Map<CareCoordinationClientAPI.Dto.CCRequestDto>(query)).Returns(dto);
            getCareCoordinationRequestMock.Setup(s => s.SearchRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(expected);
            var result = await handler.Handle(query, CancellationToken.None);
            Assert.Single(result);
        }

        [Fact]
        public void Constructor_ThrowsOnNullDependency()
        {
            var mapperMock = new Mock<IMapper>();
            Assert.Throws<ArgumentNullException>(() => new GetCareCoordinationsRequestsQueryHandler(null, mapperMock.Object));
        }
    }
}
