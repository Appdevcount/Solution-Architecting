using Xunit;
using Moq;
using Microsoft.Extensions.Options;
using CareCoordinationClientApi.Application.Repositories;
using CareCoordinationClientApi.Application.Dto;
using Microsoft.Azure.Cosmos;
using System.Threading;
using System.Threading.Tasks;
using CareCoordinationClientAPI.Dto;
using System.Collections.Generic;
using System;

namespace CareCoordinationClientApi.Application.Tests
{
    public class CosmosDbRepositoryTests_Full
    {
        [Fact]
        public async Task GetRequestsAsync_BuildsQueryAndReturnsResults()
        {
            var settings = new CosmosDbSettings
            {
                EndpointUri = "https://localhost:8081",
                PrimaryKey = "fakekey",
                DatabaseName = "db",
                ContainerName = "container"
            };
            var options = Options.Create(settings);

            var containerMock = new Mock<Container>();
            var feedIteratorMock = new Mock<FeedIterator<CareCoordinationClientAPI.Domain.Models.CareCoordination>>();
            var feedResponseMock = new Mock<FeedResponse<CareCoordinationClientAPI.Domain.Models.CareCoordination>>();
            feedIteratorMock.SetupSequence(f => f.HasMoreResults).Returns(true).Returns(false);
            feedIteratorMock.Setup(f => f.ReadNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(feedResponseMock.Object);
            feedResponseMock.Setup(r => r.GetEnumerator()).Returns(new List<CareCoordinationClientAPI.Domain.Models.CareCoordination> { new CareCoordinationClientAPI.Domain.Models.CareCoordination() }.GetEnumerator());
            containerMock.Setup(c => c.GetItemQueryIterator<CareCoordinationClientAPI.Domain.Models.CareCoordination>(It.IsAny<QueryDefinition>(), null, null)).Returns(feedIteratorMock.Object);

            var cosmosClientMock = new Mock<CosmosClient>(MockBehavior.Strict, settings.EndpointUri, settings.PrimaryKey);
            cosmosClientMock.Setup(c => c.GetContainer(settings.DatabaseName, settings.ContainerName)).Returns(containerMock.Object);

            var repo = (CosmosDbRepository)Activator.CreateInstance(typeof(CosmosDbRepository), true);
            typeof(CosmosDbRepository).GetField("_cosmosClient", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).SetValue(repo, cosmosClientMock.Object);
            typeof(CosmosDbRepository).GetField("_container", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).SetValue(repo, containerMock.Object);

            var dto = new CCRequestDto { CCRequestId = "id", PatientId = "pid", PatientFirstname = "fn", PatientLastname = "ln", PatientDOB = DateTime.Now };
            var result = await repo.GetRequestsAsync(dto);
            Assert.NotNull(result);
        }
    }
}
