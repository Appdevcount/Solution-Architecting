using Xunit;
using Moq;
using Microsoft.Extensions.Options;
using CareCoordinationClientApi.Application.Repositories;
using CareCoordinationClientApi.Application.Dto;
using System;

namespace CareCoordinationClientApi.Application.Tests
{
    public class CosmosDbRepositoryTests
    {
        [Fact]
        public void Constructor_InitializesClientAndContainer()
        {
            var settings = new CosmosDbSettings
            {
                EndpointUri = "https://localhost:8081",
                PrimaryKey = "fakekey",
                DatabaseName = "db",
                ContainerName = "container"
            };
            var options = Options.Create(settings);
            var repo = new CosmosDbRepository(options);
            Assert.NotNull(repo);
        }
    }
}
