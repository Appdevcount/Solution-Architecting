using Xunit;
using Moq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using CareCoordinationClientApi.Application.Services;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Dto;
using System.Collections.Generic;
using CareCoordinationClientAPI.Domain.Models;

namespace CareCoordinationClientApi.Application.Tests
{
    public class GetCareCoordinationRequestTests
    {
        private readonly Mock<ICosmosDbRepository> _cosmosMock = new();
        private readonly Mock<ISqlRepository> _sqlMock = new();
        private readonly Mock<IMapper> _mapperMock = new();
        private readonly GetCareCoordinationRequest _service;

        public GetCareCoordinationRequestTests()
        {
            _service = new GetCareCoordinationRequest(_cosmosMock.Object, _sqlMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task SearchRequestsAsync_ReturnsOrderedRequests()
        {
            var dto = new CCRequestDto();
            var cosmosList = new List<CareCoordination> { new CareCoordination { RequestedServiceDate = new DateTime(2024,1,2) } };
            var sqlList = new List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne> {
                new CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne { CareCoordinationEpisodeId = "1", RequestedServiceDate = new DateTime(2024,1,1) }
            };
            var groupedSql = new List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne> { sqlList[0] };
            var mappedSql = new List<CareCoordination> { new CareCoordination { RequestedServiceDate = new DateTime(2024,1,1) } };
            _cosmosMock.Setup(x => x.GetRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(cosmosList);
            _sqlMock.Setup(x => x.GetRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(sqlList);
            _mapperMock.Setup(x => x.Map<List<CareCoordination>>(It.IsAny<List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne>>())).Returns(mappedSql);
            var result = await _service.SearchRequestsAsync(dto);
            Assert.Equal(2, result.Count);
            Assert.True(result[0].RequestedServiceDate < result[1].RequestedServiceDate);
        }

        [Fact]
        public async Task Constructor_ThrowsOnNullDependencies()
        {
            Assert.Throws<ArgumentNullException>(() => new GetCareCoordinationRequest(null, _sqlMock.Object, _mapperMock.Object));
            Assert.Throws<ArgumentNullException>(() => new GetCareCoordinationRequest(_cosmosMock.Object, null, _mapperMock.Object));
        }

        [Fact]
        public async Task SearchRequestsAsync_MapsAllPropertiesAndProcedureCodes()
        {
            var dto = new CCRequestDto();
            var sqlList = new List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne> {
                new CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne {
                    CareCoordinationEpisodeId = "1",
                    CareCoordinationEpisodeDate = new DateTime(2024,1,1),
                    CaseStatus = "Open",
                    RequesterFName = "John",
                    RequesterLName = "Doe",
                    RequesterContactNo = "123",
                    RequesterContactExt = "456",
                    RequesterFaxNo = "789",
                    RequesterFacility = "Facility",
                    RequesterEmailID = "john@doe.com",
                    HealthPlan = "PlanA",
                    ProgramType = "TypeA",
                    Reason = "ReasonA",
                    DateOfService = new DateTime(2024,1,2),
                    DateOfClosing = new DateTime(2024,1,3),
                    MissedStartOfCare = true,
                    MissedStartOfCareReason = "ReasonB",
                    IsEscalated = false,
                    FollowUpDate = new DateTime(2024,1,4),
                    FollowUpNotes = "Notes",
                    CaseManagerFName = "CMF",
                    CaseManagerLName = "CML",
                    CaseManagerPhoneNo = "999",
                    CaseManagerExtention = "888",
                    CaseManagerEmail = "cm@doe.com",
                    AssigneeEmailId = "assignee@doe.com",
                    AssigneeName = "Assignee",
                    AssigneeDate = new DateTime(2024,1,5),
                    CreatedBy = "Creator",
                    SubServiceType = "SubType",
                    StaffedRequest = "Staffed",
                    CloseReason = "Closed",
                    ProcedureId = 1,
                    CptCode = "CPT1",
                    CptName = "CPTName",
                    CPTSimplifiedDesc = "Desc",
                    ProcedureCreatedBy = "ProcBy",
                    ProcedureCreatedDate = new DateTime(2024,1,6),
                    PrivateDutyNurse = true,
                    CustomNeed = "Need"
                },
                // Add a second item with null/empty CptCode to test that branch
                new CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne {
                    CareCoordinationEpisodeId = "1",
                    CptCode = null
                }
            };
            var cosmosList = new List<CareCoordination>();
            _cosmosMock.Setup(x => x.GetRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(cosmosList);
            _sqlMock.Setup(x => x.GetRequestsAsync(dto, It.IsAny<CancellationToken>())).ReturnsAsync(sqlList);
            _mapperMock.Setup(x => x.Map<List<CareCoordination>>(It.IsAny<List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne>>()))
                .Returns(new List<CareCoordination> {
                    new CareCoordination {
                        RequestedServiceDate = new DateTime(2024,1,1)
                    }
                });
            var result = await _service.SearchRequestsAsync(dto);
            Assert.Single(result);
            _mapperMock.Verify(x => x.Map<List<CareCoordination>>(It.Is<List<CareCoordinationClientApi.Application.Dto.CareCoordinationRequestFromImageOne>>(l =>
                l[0].CareCoordinationEpisodeId == "1" &&
                l[0].CaseStatus == "Open" &&
                l[0].RequesterFName == "John" &&
                l[0].CptCode == "CPT1" &&
                l[0].ProcedureId == 1
            )), Times.Once);
        }
    }
}
