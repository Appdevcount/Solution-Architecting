using Xunit;
using Moq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using FluentValidation;
using MediatR;
using CareCoordinationClientAPI.Controllers;
using CareCoordinationClientAPI.Dto;
using CareCoordinationClientAPI.Queries;
using CareCoordinationClientApi.Application.Logger;
using System.Collections.Generic;
using System.Net;
using System;

namespace CareCoordinationClientApi.Application.Tests
{
    public class RequestSearchControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock = new();
        private readonly Mock<IValidator<CCRequestDto>> _validatorMock = new();
        private readonly Mock<IApplicationLogger> _loggerMock = new();
        private readonly Mock<IMapper> _mapperMock = new();
        private readonly RequestSearchController _controller;

        public RequestSearchControllerTests()
        {
            _controller = new RequestSearchController(_mediatorMock.Object, _validatorMock.Object, _loggerMock.Object, _mapperMock.Object);
        }

        [Fact]
        public async Task GetCareCoordinationRequests_ReturnsBadRequest_WhenValidationFails()
        {
            var dto = new CCRequestDto();
            _validatorMock.Setup(v => v.ValidateAsync(dto, default)).ReturnsAsync(new FluentValidation.Results.ValidationResult(new List<FluentValidation.Results.ValidationFailure> { new("field", "error") }));
            var result = await _controller.GetCareCoordinationRequests(dto);
            Assert.IsType<BadRequestObjectResult>(result);
        }

        [Fact]
        public async Task GetCareCoordinationRequests_ReturnsNotFound_WhenNoRecords()
        {
            var dto = new CCRequestDto();
            _validatorMock.Setup(v => v.ValidateAsync(dto, default)).ReturnsAsync(new FluentValidation.Results.ValidationResult());
            _mapperMock.Setup(m => m.Map<GetCareCoordinationRequestsQuery>(dto)).Returns(new GetCareCoordinationRequestsQuery("","",null,"",""));
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetCareCoordinationRequestsQuery>(), default)).ReturnsAsync((List<object>)null);
            var result = await _controller.GetCareCoordinationRequests(dto);
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task GetCareCoordinationRequests_ReturnsOk_WhenRecordsFound()
        {
            var dto = new CCRequestDto();
            _validatorMock.Setup(v => v.ValidateAsync(dto, default)).ReturnsAsync(new FluentValidation.Results.ValidationResult());
            _mapperMock.Setup(m => m.Map<GetCareCoordinationRequestsQuery>(dto)).Returns(new GetCareCoordinationRequestsQuery("","",null,"",""));
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetCareCoordinationRequestsQuery>(), default)).ReturnsAsync(new List<object> { new() });
            var result = await _controller.GetCareCoordinationRequests(dto);
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async Task GetCareCoordinationRequests_ReturnsInternalServerError_OnException()
        {
            var dto = new CCRequestDto();
            _validatorMock.Setup(v => v.ValidateAsync(dto, default)).ThrowsAsync(new Exception("fail"));
            var result = await _controller.GetCareCoordinationRequests(dto);
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, objectResult.StatusCode);
        }
    }
}
