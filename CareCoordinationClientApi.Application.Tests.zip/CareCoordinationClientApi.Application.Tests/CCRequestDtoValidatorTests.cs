using Xunit;
using CareCoordinationClientAPI.Validators;
using CareCoordinationClientAPI.Dto;

namespace CareCoordinationClientApi.Application.Tests
{
    public class CCRequestDtoValidatorTests
    {
        [Theory]
        [InlineData("id", null, null, null, null, true)]
        [InlineData(null, "pid", null, null, null, true)]
        [InlineData(null, null, "fn", "ln", "2020-01-01", true)]
        [InlineData(null, null, null, null, null, false)]
        public void HasRequiredInput_Validation(string ccRequestId, string patientId, string firstName, string lastName, string dob, bool expected)
        {
            var dto = new CCRequestDto
            {
                CCRequestId = ccRequestId,
                PatientId = patientId,
                PatientFirstname = firstName,
                PatientLastname = lastName,
                PatientDOB = string.IsNullOrEmpty(dob) ? (DateTime?)null : DateTime.Parse(dob)
            };
            var validator = new CCRequestDtoValidator();
            var result = validator.Validate(dto);
            Assert.Equal(expected, result.IsValid);
        }
    }
}
