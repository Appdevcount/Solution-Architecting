﻿using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using CareCoordinationClientApi.Application.Dto;

namespace CareCoordinationClientApi.Application.Services
{
    public class GetCareCoordinationRequest : IGetCareCoordinationRequest
    {
        private readonly ICosmosDbRepository _cosmosDbRepository;
        private readonly ISqlRepository _sqlRepository;
        private readonly IMapper mapper;

        public GetCareCoordinationRequest(ICosmosDbRepository cosmosDbRepository, ISqlRepository sqlRepository, IMapper mapper)
        {
            _cosmosDbRepository = cosmosDbRepository ?? throw new ArgumentNullException(nameof(cosmosDbRepository));
            _sqlRepository = sqlRepository ?? throw new ArgumentNullException(nameof(sqlRepository));
            this.mapper = mapper;
        }

        public async Task<List<CareCoordination>> SearchRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default)
        {

            var cosmosRequests = await _cosmosDbRepository.GetRequestsAsync(cCRequestDto, cancellationToken) ?? new List<CareCoordination>();
            var sqlRequests = await _sqlRepository.GetRequestsAsync(cCRequestDto, cancellationToken) ?? new List<Dto.CareCoordinationRequestFromImageOne>();
            var groupedsqlRequests = sqlRequests
                        .GroupBy(x => x.CareCoordinationEpisodeId)
                        .Select(g =>
                        {
                            var first = g.First();

                            return new CareCoordinationRequestFromImageOne
                            {
                                CareCoordinationEpisodeId = first.CareCoordinationEpisodeId,
                                CareCoordinationEpisodeDate = first.CareCoordinationEpisodeDate,
                                CaseStatus = first.CaseStatus,
                                RequesterFName = first.RequesterFName,
                                RequesterLName = first.RequesterLName,
                                RequesterContactNo = first.RequesterContactNo,
                                RequesterContactExt = first.RequesterContactExt,
                                RequesterFaxNo = first.RequesterFaxNo,
                                RequesterFacility = first.RequesterFacility,
                                RequesterEmailID = first.RequesterEmailID,
                                HealthPlan = first.HealthPlan,
                                ProgramType = first.ProgramType,
                                Reason = first.Reason,
                                DateOfService = first.DateOfService,
                                DateOfClosing = first.DateOfClosing,
                                MissedStartOfCare = first.MissedStartOfCare,
                                MissedStartOfCareReason = first.MissedStartOfCareReason,
                                IsEscalated = first.IsEscalated,
                                FollowUpDate = first.FollowUpDate,
                                FollowUpNotes = first.FollowUpNotes,
                                CaseManagerFName = first.CaseManagerFName,
                                CaseManagerLName = first.CaseManagerLName,
                                CaseManagerPhoneNo = first.CaseManagerPhoneNo,
                                CaseManagerExtention = first.CaseManagerExtention,
                                CaseManagerEmail = first.CaseManagerEmail,
                                AssigneeEmailId = first.AssigneeEmailId,
                                AssigneeName = first.AssigneeName,
                                AssigneeDate = first.AssigneeDate,
                                CreatedBy = first.CreatedBy,
                                SubServiceType = first.SubServiceType,
                                StaffedRequest = first.StaffedRequest,
                                CloseReason = first.CloseReason,

                                ProcedureCodes = g
                                    .Where(x => !string.IsNullOrEmpty(x.CptCode))
                                    .Select(x => new Dto.ProcedureCode
                                    {
                                        ProcedureId = x.ProcedureId,
                                        CptCode = x.CptCode,
                                        CptName = x.CptName,
                                        CPTSimplifiedDesc = x.CPTSimplifiedDesc,
                                        ProcedureCreatedBy = x.ProcedureCreatedBy,
                                        ProcedureCreatedDate = x.ProcedureCreatedDate,
                                        PrivateDutyNurse = x.PrivateDutyNurse,
                                        CustomNeed = x.CustomNeed
                                    })
                                    .Distinct()
                                    .ToList()
                            };
                        })
                        .ToList();


            var mappedSqlRequests = mapper.Map<List<CareCoordination>>(groupedsqlRequests) ?? new List<CareCoordination>();
            var allRequests = mappedSqlRequests.Concat(cosmosRequests);


            return allRequests.OrderBy(r => r.RequestedServiceDate).ToList();
        }
    }
}
