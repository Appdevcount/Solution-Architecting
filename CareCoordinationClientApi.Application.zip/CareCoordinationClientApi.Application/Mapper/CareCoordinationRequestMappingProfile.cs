﻿using AutoMapper;
using CareCoordinationClientApi.Application.Dto;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using CareCoordinationClientAPI.Queries;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientApi.Application.Mapper
{

    [ExcludeFromCodeCoverage]
    public class CareCoordinationRequestMappingProfile : Profile
    {
        public CareCoordinationRequestMappingProfile()
        {
            CreateMap<CareCoordinationRequestFromImageOne, CareCoordination>()
                .ForMember(dest => dest.CareCoordinationId, opt => opt.MapFrom(src => src.CareCoordinationEpisodeId))
                .ForMember(dest => dest.RequestedServiceDate, opt => opt.MapFrom(src => src.DateOfService))
                .ForMember(dest => dest.DateOfClosing, opt => opt.MapFrom(src => src.DateOfClosing))

                .ForMember(dest => dest.Requester, opt => opt.MapFrom(src => new RequesterDetails
                {
                    FirstName = src.RequesterFName,
                    LastName = src.RequesterLName,
                    PhoneNumber = src.RequesterContactNo,
                    Extension = src.RequesterContactExt,
                    Fax = src.RequesterFaxNo,
                    Email = src.RequesterEmailID,
                    Facility = src.RequesterFacility
                }))

                .ForMember(dest => dest.MemberPolicy, opt => opt.MapFrom(src => new MemberPolicyDTO
                {
                    MemberId = src.PatientID,
                    FirstName = src.PatientName,
                    LastName = src.PatientName,
                    DateOfBirth = src.PatientDOB,
                    AddressLine1 = src.PatientAddr1,
                    AddressLine2 = src.PatientAddr2,
                    City = src.PatientCity,
                    StateCode = src.PatientState,
                    ZipCode = src.PatientZip,
                    Gender = src.PatientSex,
                    GroupNumber = src.GroupNumber,
                    PrimaryLanguage = src.Language,
                    IsMemberQuickCreate = src.MemberQuickCreate,
                    IsMemberEligible = !src.IsRestrictedMember.HasValue || !src.IsRestrictedMember.Value
                }))

                .ForMember(dest => dest.ReasonDetails, opt => opt.MapFrom(src => new ReasonDetails
                {
                    Reason = src.Reason,
                    Notes = src.FollowUpNotes,
                    StartOfCareDate = src.CareCoordinationEpisodeDate
                }))
                .ForMember(dest => dest.StatusDetails, opt => opt.MapFrom(src => new StatusDetails
                {
                    Status = src.CaseStatus,
                    Notes = src.FollowUpNotes
                }))

                .ForMember(dest => dest.ProcedureCodes, opt => opt.MapFrom(src =>
                src.ProcedureCodes.Select(i => new CareCoordinationClientAPI.Domain.Models.ProcedureCode
                {
                    Name = i.CptCode,
                    SimplifiedDescription = i.CPTSimplifiedDesc,
                    Units = null
                }).ToList()

                ))

                .ForMember(dest => dest.Providers, opt => opt.MapFrom(src => new List<ProviderContract>
                {
                new ProviderContract
                {
                    Fax = src.SiteFax,
                    Phone = src.SitePhone,
                    Zip = src.SiteZip,
                    StateCode = src.SiteState,
                    City = src.SiteCity,
                    Address1 = src.SiteAddr1,
                    Address2 = src.SiteAddr2,
                    NPI = src.NPI,
                    FirstName = src.PhysicianName,
                    OrganizationName = src.SiteName,
                    ProviderTypeIdentifier = src.SiteType,
                    IsParticipatingProvider = src.SiteNYMIPar == "Y",
                    ProviderNetworkType = src.SiteIPA,
                    SourceNotes = src.SiteSpecDesc1
                }
                }));

            //.ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<GetCareCoordinationRequestsQuery, CCRequestDto>().ReverseMap();
        }
    }



}
