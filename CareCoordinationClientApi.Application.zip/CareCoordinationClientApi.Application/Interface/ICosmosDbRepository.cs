﻿using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientApi.Application.Interface
{
    public interface ICosmosDbRepository
    {
        Task<List<CareCoordination>> GetRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default);
    }
}
