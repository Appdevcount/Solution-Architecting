﻿using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientApi.Application.Interface
{
    public interface IGetCareCoordinationRequest
    {
        Task<List<CareCoordination>> SearchRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default);
    }
}
