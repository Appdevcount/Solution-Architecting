﻿using CareCoordinationClientApi.Application.Dto;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientApi.Application.Interface
{
    public interface ISqlRepository
    {

        Task<List<CareCoordinationRequestFromImageOne>> GetRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default);

    }
}
