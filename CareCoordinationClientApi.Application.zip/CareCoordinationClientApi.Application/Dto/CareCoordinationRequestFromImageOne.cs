﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientApi.Application.Dto
{
    [ExcludeFromCodeCoverage]
    public class CareCoordinationRequestFromImageOne
    {
        public string? CareCoordinationEpisodeId { get; set; }
        public DateTime? CareCoordinationEpisodeDate { get; set; }
        public string? CaseStatus { get; set; }
        public string? RequesterFName { get; set; }
        public string? RequesterLName { get; set; }
        public string? RequesterContactNo { get; set; }
        public string? RequesterContactExt { get; set; }
        public string? RequesterFaxNo { get; set; }
        public string? RequesterFacility { get; set; }
        public string? RequesterEmailID { get; set; }
        public string? HealthPlan { get; set; }
        public string? ProgramType { get; set; }
        public string? Reason { get; set; }
        public DateTime? DateOfService { get; set; }
        public DateTime? DateOfClosing { get; set; }
        public bool? MissedStartOfCare { get; set; }
        public string? MissedStartOfCareReason { get; set; }
        public bool? IsEscalated { get; set; }
        public DateTime? FollowUpDate { get; set; }
        public string? FollowUpNotes { get; set; }
        public string? CaseManagerFName { get; set; }
        public string? CaseManagerLName { get; set; }
        public string? CaseManagerPhoneNo { get; set; }
        public string? CaseManagerExtention { get; set; }
        public string? CaseManagerEmail { get; set; }
        public string? AssigneeEmailId { get; set; }
        public string? AssigneeName { get; set; }
        public DateTime? AssigneeDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? SubServiceType { get; set; }
        public string? StaffedRequest { get; set; }
        public string? CloseReason { get; set; }

        // Member Info
        public string? OAOSubNo { get; set; }
        public string? OAOPerNo { get; set; }
        public string? OAOEmpNo { get; set; }
        public string? PatientID { get; set; }
        public string? PatientMemberCode { get; set; }
        public string? PatientName { get; set; }
        public string? PatientAddr1 { get; set; }
        public string? PatientAddr2 { get; set; }
        public string? PatientCity { get; set; }
        public string? PatientState { get; set; }
        public string? PatientZip { get; set; }
        public string? PatientSex { get; set; }
        public string? PatientPhone { get; set; }
        public DateTime? PatientDOB { get; set; }
        public string? GroupNumber { get; set; }
        public string? PlanType { get; set; }
        public string? LineOfBusiness { get; set; }
        public string? Language { get; set; }
        public string? PatientPlanType { get; set; }
        public string? PatientEntity { get; set; }
        public string? Category { get; set; }
        public string? PatientIPA { get; set; }
        public string? PatientIdent { get; set; }
        public string? PatientEmail { get; set; }
        public string? CellPhone { get; set; }
        public string? JurisdictionState { get; set; }
        public string? TIT19 { get; set; }
        public string? CaseFactor { get; set; }
        public string? PatientPUSRDF { get; set; }
        public string? FundType { get; set; }
        public string? ERISA { get; set; }
        public string? EXTID { get; set; }
        public DateTime? MemberStartDate { get; set; }
        public bool? MemberQuickCreate { get; set; }
        public bool? IsRestrictedMember { get; set; }

        // Notes
        //public string? Notes { get; set; }
        //public string? NoteCreatedBy { get; set; }
        //public DateTime? NoteCreatedDate { get; set; }

        // Procedure Codes
        public List<ProcedureCode> ProcedureCodes { get; set; }
        public int? ProcedureId { get; set; }
        public string? CptCode { get; set; }
        public string? CptName { get; set; }
        public string? CPTSimplifiedDesc { get; set; }
        public string? ProcedureCreatedBy { get; set; }
        public DateTime? ProcedureCreatedDate { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public string? CustomNeed { get; set; }

        // Provider
        public string? OAOSiteID { get; set; }
        public string? NonParSiteID { get; set; }
        public string? OldSiteID { get; set; }
        public string? SiteName { get; set; }
        public string? SiteAddr1 { get; set; }
        public string? SiteAddr2 { get; set; }
        public string? SiteCity { get; set; }
        public string? SiteState { get; set; }
        public string? SiteZip { get; set; }
        public string? SitePhone { get; set; }
        public string? SiteFax { get; set; }
        public string? SiteSpec1 { get; set; }
        public string? SiteSpec2 { get; set; }
        public string? SiteSpecDesc1 { get; set; }
        public string? SiteSpecDesc2 { get; set; }
        public string? SiteAlternateID { get; set; }
        public string? SiteNYMIPar { get; set; }
        public string? SteeragePosition { get; set; }
        public string? NPI { get; set; }
        public string? SiteIdent { get; set; }
        public string? SelectionMethodID { get; set; }
        public string? ProviderEmail { get; set; }
        public string? PUSRDF { get; set; }
        public string? SiteIPA { get; set; }
        public string? SiteEntity { get; set; }
        public string? SiteType { get; set; }
        public string? PhysicianName { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ProcedureCode
    {
        public int? ProcedureId { get; set; }
        public string? CptCode { get; set; }
        public string? CptName { get; set; }
        public string? CPTSimplifiedDesc { get; set; }
        public string? ProcedureCreatedBy { get; set; }
        public DateTime? ProcedureCreatedDate { get; set; }
        public bool? PrivateDutyNurse { get; set; }
        public string? CustomNeed { get; set; }
    }

}
