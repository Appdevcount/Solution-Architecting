﻿using System.Diagnostics.CodeAnalysis;

namespace CareCoordinationClientAPI.Dto
{
    [ExcludeFromCodeCoverage]
    public class CCRequestDto
    {
        public string? CCRequestId { get; set; }
        public string? PatientId { get; set; }
        public string? PatientFirstname { get; set; }
        public string? PatientLastname { get; set; }
        public DateTime? PatientDOB { get; set; }
    }

}
