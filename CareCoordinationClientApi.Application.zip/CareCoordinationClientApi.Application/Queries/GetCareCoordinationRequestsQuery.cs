﻿using MediatR;
using CareCoordinationClientAPI.Domain.Models;

namespace CareCoordinationClientAPI.Queries
{
    public class GetCareCoordinationRequestsQuery : IRequest<List<CareCoordination>>
    {

        public GetCareCoordinationRequestsQuery(
         string patientFirstname,
         string patientLastname,
         DateTime? patientDOB,
         string patientId,
         string ccRequestId)
        {
            PatientFirstname = patientFirstname;
            PatientLastname = patientLastname;
            PatientDOB = patientDOB;
            PatientId = patientId;
            CCRequestId = ccRequestId;
        }

        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public DateTime? PatientDOB { get; set; }
        public string PatientId { get; set; }
        public string CCRequestId { get; set; }
    }
}
