﻿using AutoMapper;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using CareCoordinationClientAPI.Queries;
using MediatR;

namespace CareCoordinationClientAPI.Queries.Handlers
{
    public class GetCareCoordinationsRequestsQueryHandler : IRequestHandler<GetCareCoordinationRequestsQuery, List<CareCoordination>>
    {
        private readonly IGetCareCoordinationRequest _getCareCoordinationRequest;
        private readonly IMapper mapper;

        public GetCareCoordinationsRequestsQueryHandler(IGetCareCoordinationRequest getCareCoordinationRequest, IMapper mapper)
        {
            _getCareCoordinationRequest = getCareCoordinationRequest ?? throw new ArgumentNullException(nameof(getCareCoordinationRequest));
            this.mapper = mapper;
        }

        public async Task<List< CareCoordination>> Handle(GetCareCoordinationRequestsQuery request, CancellationToken cancellationToken)
        {
            var cCRequestDto = mapper.Map<CCRequestDto>(request);
            var allRequests = await _getCareCoordinationRequest.SearchRequestsAsync(cCRequestDto,cancellationToken);

            return allRequests;
            
        }

    }
}
