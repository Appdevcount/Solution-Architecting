﻿using CareCoordinationClientApi.Application.Dto;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProcedureCode = CareCoordinationClientApi.Application.Dto.ProcedureCode;

namespace CareCoordinationClientApi.Application.Repositories
{
    public class SqlRepository : ISqlRepository
    {
        private readonly string _connectionString;
        public SqlRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("PreAuthinDB")
                ?? throw new ArgumentNullException(nameof(configuration));
        }
    

        public async Task<List<CareCoordinationRequestFromImageOne>> GetRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CareCoordinationEpisodeId", cCRequestDto.CCRequestId);
                parameters.Add("@PatientID", cCRequestDto.PatientId);
                parameters.Add("@PatientFirstName", cCRequestDto.PatientFirstname);
                parameters.Add("@PatientLastName", cCRequestDto.PatientLastname);
                parameters.Add("@PatientDOB", cCRequestDto.PatientDOB);

                return (List<CareCoordinationRequestFromImageOne>)await connection.QueryAsync<CareCoordinationRequestFromImageOne>(
                "dbo.GetCareCoordinationRecentHistoricalRequests",
                parameters,
                commandType: CommandType.StoredProcedure
                );
            }

        }

    }
}
