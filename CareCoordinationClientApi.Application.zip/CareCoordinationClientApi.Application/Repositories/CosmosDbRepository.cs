﻿using CareCoordinationClientApi.Application.Dto;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Dapper.SqlMapper;
using Container = Microsoft.Azure.Cosmos.Container;

namespace CareCoordinationClientApi.Application.Repositories
{
    [ExcludeFromCodeCoverage]
    public class CosmosDbRepository : ICosmosDbRepository
    {
        private readonly CosmosClient _cosmosClient;
        private readonly Container _container;

        public CosmosDbRepository(IOptions<CosmosDbSettings> cosmosSettings)
        {
            var settings = cosmosSettings.Value;
            _cosmosClient = new CosmosClient(settings.EndpointUri, settings.PrimaryKey);
            _container = _cosmosClient.GetContainer(settings.DatabaseName, settings.ContainerName);
        }
       
        public async Task<List<CareCoordination>> GetRequestsAsync(CCRequestDto cCRequestDto, CancellationToken cancellationToken = default)
        {
            var query = "SELECT * FROM c Where ";
            query += "c.RequestDate > getdate()-180";
            if (!string.IsNullOrEmpty(cCRequestDto.CCRequestId))
            {
                query += "c.MemberPolicy.RequestId = @RequestId";
            }
            if (!string.IsNullOrEmpty(cCRequestDto.PatientId))
            {
                query += "c.MemberPolicy.MemberId = @PatientId";
            }
            //if (!string.IsNullOrEmpty(cCRequestDto.PatientFirstName))
            //{
            //    query += "c.MemberPolicy.PatientFirstName = @PatientFirstName";
            //}
            //if (!string.IsNullOrEmpty(cCRequestDto.PatientLastName))
            //{
            //    query += "c.MemberPolicy.PatientLastName = @PatientLastName";
            //}
            if (cCRequestDto.PatientDOB !=null)
            {
                query += "c.MemberPolicy.PatientDOB = @PatientDOB";
            }

            var queryDefinition = new QueryDefinition(query);
            if (!string.IsNullOrEmpty(cCRequestDto.CCRequestId))
            {
                queryDefinition.WithParameter("@RequestId", cCRequestDto.CCRequestId);
            }
            if (!string.IsNullOrEmpty(cCRequestDto.PatientId))
            {
                queryDefinition.WithParameter("@PatientId", cCRequestDto.PatientId);
            }

            //if (!string.IsNullOrEmpty(PatientFirstName))
            //{
            //    queryDefinition.WithParameter("@PatientFirstName", PatientFirstName);
            //}
            //if (!string.IsNullOrEmpty(PatientLastName))
            //{
            //    queryDefinition.WithParameter("@PatientLastName", PatientLastName);
            //}
            if (cCRequestDto.PatientDOB != null)
            {
                queryDefinition.WithParameter("@PatientDOB", cCRequestDto.PatientDOB);
            }


            var results = new List<CareCoordination>();
            using (FeedIterator<CareCoordination> resultSet = _container.GetItemQueryIterator<CareCoordination>(queryDefinition))
            {
                while (resultSet.HasMoreResults)
                {
                    FeedResponse<CareCoordination> response = await resultSet.ReadNextAsync();
                    results.AddRange(response);
                }
            }

            return results;
        }


    }
}
