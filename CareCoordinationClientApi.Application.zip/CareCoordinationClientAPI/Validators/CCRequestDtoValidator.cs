﻿using CareCoordinationClientAPI.Dto;
using FluentValidation;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordinationClientAPI.Validators
{

    [ExcludeFromCodeCoverage]
    public class CCRequestDtoValidator : AbstractValidator<CCRequestDto>
    {
        public CCRequestDtoValidator()
        {
            RuleFor(x => x)
                .Must(HasRequiredInput)
                .WithMessage("Either CCRequestId, PatientId, or the combination of PatientFirstname, PatientLastname, and PatientDOB must be provided.")
                .WithName("HasRequiredInput"); 
        }

        private bool HasRequiredInput(CCRequestDto dto)
        {
            bool hasCCRequestId = !string.IsNullOrEmpty(dto.CCRequestId);
            bool hasPatientId = !string.IsNullOrEmpty(dto.PatientId);
            bool hasPatientInfo =
                !string.IsNullOrEmpty(dto.PatientFirstname) &&
                !string.IsNullOrEmpty(dto.PatientLastname) &&
                dto.PatientDOB.HasValue;

            return hasCCRequestId || hasPatientId || hasPatientInfo;
        }
    }

}
