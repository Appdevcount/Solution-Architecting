using CareCoordinationClientApi.Application.Dto;
using CareCoordinationClientApi.Application.Interface;
using CareCoordinationClientApi.Application.Logger;
using CareCoordinationClientApi.Application.Repositories;
using CareCoordinationClientApi.Application.Services;
using CareCoordinationClientAPI.Queries;
using CareCoordinationClientAPI.Queries.Handlers;
using CareCoordinationClientAPI.Validators;
using FluentValidation;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.Configure<CosmosDbSettings>(builder.Configuration.GetSection("CosmosDb"));

builder.Services.AddSingleton<ISqlRepository, SqlRepository>();
builder.Services.AddSingleton<ICosmosDbRepository, CosmosDbRepository>();
builder.Services.AddSingleton<IGetCareCoordinationRequest, GetCareCoordinationRequest>();
builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssembly(typeof(GetCareCoordinationsRequestsQueryHandler).Assembly);
});


builder.Services.AddValidatorsFromAssemblyContaining<CCRequestDtoValidator>();

//builder.Services.Configure<ApiBehaviorOptions>(options =>
//{
//    options.SuppressModelStateInvalidFilter = true;
//});

builder.Services.AddSingleton<IApplicationLogger, AppInsightsLogger>();

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAdB2C"));

builder.Services.AddAuthorization();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
