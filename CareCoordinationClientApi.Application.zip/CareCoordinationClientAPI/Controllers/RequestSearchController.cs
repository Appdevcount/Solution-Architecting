﻿using AutoMapper;
using Azure.Core;
using CareCoordinationClientApi.Application.Logger;
using CareCoordinationClientAPI.Domain.Models;
using CareCoordinationClientAPI.Dto;
using CareCoordinationClientAPI.Queries;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace CareCoordinationClientAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestSearchController : ControllerBase
    {

        private readonly IMediator _mediator;
        private readonly IValidator<CCRequestDto> validator;
        private readonly IApplicationLogger logger;
        private readonly IMapper mapper;

        public RequestSearchController(IMediator mediator,IValidator<CCRequestDto> validator, IApplicationLogger logger, IMapper mapper)
        {
            _mediator = mediator;
            this.validator = validator;
            this.logger = logger;
            this.mapper = mapper;
        }

        [HttpPost(Name = "GetCareCoordinationRequests")]
        public async Task<IActionResult> GetCareCoordinationRequests([FromBody] CCRequestDto cCRequestDto)
        {
            try
            {
                FluentValidation.Results.ValidationResult result = await validator.ValidateAsync(cCRequestDto);
                if (!result.IsValid)
                    return BadRequest(result.Errors);

                var query= mapper.Map<GetCareCoordinationRequestsQuery>(cCRequestDto);

                var response = await _mediator.Send(query);

                if (response == null || response.Count == 0)
                {
                    return NotFound("No care coordination records found.");
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                logger.LogException($"{typeof(RequestSearchController).Name}: " , ex);
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);// "Some error has occured");
            }
        }


    }
}

