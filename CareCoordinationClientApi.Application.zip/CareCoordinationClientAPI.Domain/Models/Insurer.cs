﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    
    public class Insurer
    {
        
        public string InsuranceCarrierName { get; set; }

        
        public string InsuranceCarrierDisplayName { get; set; }
    }
}