﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class ServiceTypeDTO
    {
        /// <summary>
        /// Service Type ANSI Code
        /// </summary>
        
        public string ServiceTypeCode { get; set; }

        /// <summary>
        /// ServiceLevel Name
        /// </summary>
        
        public string ServiceType { get; set; }

    }
}