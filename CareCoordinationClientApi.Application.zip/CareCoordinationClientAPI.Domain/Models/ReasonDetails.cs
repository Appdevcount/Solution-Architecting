﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class ReasonDetails
    {
        
        public string Reason { get; set; }
        
        public string Notes { get; set; }
        
        public DateTime? StartOfCareDate { get; set; }

    }
}