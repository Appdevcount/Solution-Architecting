﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class ProcedureCode
    {
        
        public string Name { get; set; }
        
        public string SimplifiedDescription { get; set; }
        
        public string Units { get; set; }

    }
}