﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class StatusDetails
    {
        
        public string Status { get; set; } = Statuses.OpenStatus;//Default value
        
        public string Notes { get; set; }//Notes for the current status
    }

    [ExcludeFromCodeCoverage]
    internal class Statuses
    {
        public const string OpenStatus = "Open";
        public const string ClosedStatus = "Closed";
        public const string InProgressStatus = "InProgress";
    }
}