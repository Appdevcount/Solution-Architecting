﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class CareCoordination
    {
        public Guid? RequestForCareCoordinationKey { get; set; }

        public required string CareCoordinationId { get; set; }

        public RequestedServicesDto RequestedServices { get; set; }

        public MemberPolicyDTO MemberPolicy { get; set; }

        public DateTime? RequestedServiceDate { get; set; }

        public IEnumerable<ProviderContract> Providers { get; set; }

        public IEnumerable<ProcedureCode> ProcedureCodes { get; set; }

        public RequesterDetails Requester { get; set; }

        public ReasonDetails ReasonDetails { get; set; }

        public Insurer Insurer { get; set; }

        public StatusDetails StatusDetails { get; set; }

        public DateTime? DateOfClosing { get; set; }
    }
}
