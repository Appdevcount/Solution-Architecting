﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class RequesterDetails
    {
        
        public string FirstName { get; set; }
        
        public string LastName { get; set; }
        
        public string PhoneNumber { get; set; }
        
        public string Extension { get; set; }

        
        public string Fax { get; set; }
        
        public string Email { get; set; }
        
        public string Facility { get; set; }
    }
}