﻿
using Newtonsoft.Json.Converters;
using System.Diagnostics.CodeAnalysis;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class ShortDateConverter : IsoDateTimeConverter
    {
        public ShortDateConverter()
        {
            base.DateTimeFormat = "yyyy-MM-dd";
        }
    }
}