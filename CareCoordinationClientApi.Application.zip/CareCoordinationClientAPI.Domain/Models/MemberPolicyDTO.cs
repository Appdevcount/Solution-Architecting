﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class MemberPolicyDTO
    {
        /// <summary>
        /// The Insurance Carrier Key associated with the service request.
        /// </summary>
        
        public Guid? InsuranceCarrierKey { get; set; }

        /// <summary>
        /// The Key representing a Member Policy
        /// </summary>
        
        public Guid? MemberPolicyKey { get; set; }

        /// <summary>
        /// Quick Create Provided Member Id
        /// </summary>
        
        public string MemberId { get; set; } //TODO: Align with stuff and things

        /// <summary>
        /// Newly Added by Ankita
        /// </summary>
        
        public string Gender { get; set; }
        /// <summary>
        /// Quick Create Provided First Name
        /// </summary>
        
        public string FirstName { get; set; }

        /// <summary>
        /// Quick Create Provided Last Name
        /// </summary>
        
        public string MiddleName { get; set; }

        /// <summary>
        /// Quick Create Provided Last Name
        /// </summary>
        
        public string LastName { get; set; }

        /// <summary>
        /// Quick Create member Date Of Birth
        /// </summary>
        
        //[JsonConverter(typeof(ShortDateConverter))]
        //[DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        /// <summary>
        /// Quick Create Provider Address Line-1
        /// </summary>
        
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Quick Create Provider Address Line-1
        /// </summary>
        
        public string AddressLine2 { get; set; }
        /// <summary>
        /// Quick Create Provider City
        /// </summary>
        
        public string City { get; set; }

        /// <summary>
        /// Quick Create member county
        /// </summary>
        
        public string County { get; set; }

        /// <summary>
        /// Quick Create member two digit state code
        /// </summary>
        
        public string StateCode { get; set; }

        /// <summary>
        /// Added zip code for Member
        /// </summary>
        
        public String ZipCode { get; set; }

        /// <summary>
        /// GroupNumber
        /// </summary>
        
        public string GroupNumber { get; set; }

        /// <summary>
        /// This is not mandaotry field and can be used when information is available
        /// </summary>
        
        public string PrimaryLanguage { get; set; }

        /// <summary>
        /// This property is to track if Member is QuickCreated or Not
        /// </summary>
        
        public bool? IsMemberQuickCreate { get; set; }

        /// <summary>
        /// This property is to track if member is eligible or not
        /// </summary>
        
        public bool IsMemberEligible { get; set; }
    }
}