﻿namespace CareCoordinationClientAPI.Domain.Models
{
    public enum ProviderType
    {
        Requesting,
        Ordering,
        Servicing
    }
}