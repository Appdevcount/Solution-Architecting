﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class RequestedServicesDto
    {
        
        public string Program { get; set; }

        
        public string ServicePlaceCode { get; set; }

        
        public string ServicePlace { get; set; }

        
        public string ServicePlaceFullName { get; set; }

        
        public List<ServiceTypeDTO> ServiceTypes { get; set; }

    }
}