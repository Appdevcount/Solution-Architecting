﻿using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace CareCoordinationClientAPI.Domain.Models
{
    [ExcludeFromCodeCoverage]
    public class ProviderContract
    {
        public string Fax { get; set; }

        public string PhoneExtension { get; set; }

        public string Phone { get; set; }

        public string Zip { get; set; }

        public string StateCode { get; set; }

        public string County { get; set; }

        public string City { get; set; }

        public string Address2 { get; set; }

        public string Address1 { get; set; }

        public Guid? AddressKey { get; set; }

        public string TIN { get; set; }

        public string NPI { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string OrganizationName { get; set; }

        public ProviderType ProviderType { get; set; }

        /// <summary>
        /// This property contains type of provider. For example it can contain value like FA – Facilities, IP – Individual Providers,PR – Provider Groups
        /// </summary>
        public string ProviderTypeIdentifier { get; set; }

        public Guid? ProviderContractKey { get; set; }

        public Guid? SourceDataProviderKey { get; set; }

        [DataMember]
        public bool? IsParticipatingProvider { get; set; }

        [DataMember]
        public bool IsQuickCreate { get; set; }
        [DataMember]
        public string ProviderNetworkType { get; set; }
        [DataMember]
        public string QuickCreateSource { get; set; }
        [DataMember]
        public string SourceNotes { get; set; }
    }
}