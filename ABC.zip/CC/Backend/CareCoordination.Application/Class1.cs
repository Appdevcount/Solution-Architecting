﻿namespace CareCoordination.Application;

public class Class1
{

}
