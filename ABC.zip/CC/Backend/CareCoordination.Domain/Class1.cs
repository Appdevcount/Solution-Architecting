﻿namespace CareCoordination.Domain;

public class Class1
{

}
