class RequestQuery {
  RequestId: string;

  constructor(RequestId: string) {
    this.RequestId = RequestId;
  }
}
export default RequestQuery;
