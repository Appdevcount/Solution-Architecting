export type User = {
  id: string;
  email: string;
  roles: string;
  hasLEA: boolean;
  permissions : string[];
};
