export interface DeleteFilePropertiesViewModel {
    episodeId: string | null;
    objectId: number;
}