export class ResponseCloseRequestModel {
    apiError: string = ""
    apiResp: boolean = false
}

