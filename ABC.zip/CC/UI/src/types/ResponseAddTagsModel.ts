export class ResponseAddTagsModel {
    apiError: string = ""
    apiResp: boolean = false
}

