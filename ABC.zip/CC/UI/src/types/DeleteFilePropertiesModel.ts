export interface DeleteFilePropertiesModel {
    isDeleted: boolean | null;
    error: string | null;
}