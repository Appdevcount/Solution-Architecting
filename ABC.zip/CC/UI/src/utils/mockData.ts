/* istanbul ignore file */
export const Dashboardmockdata = [
    {
      followUpTime: "ABCD",
      location: "Manglore",
      requestId: "REQ12355",
      name: "John Cena",
      dob: "2000-02-17",
      memberId: "1234456",
      serviceType: "Medical",
      status: "Open",
    }
  ];
