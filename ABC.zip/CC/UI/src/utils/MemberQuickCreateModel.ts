export default interface MemberQuickCreate {
    MemberId: number;
    FirstName: string;
    LastName: string;
    Dob: string;
    Gender: string;
    StreetAddress: string;
    City: string;
    Zip: string;
    State: string;
}